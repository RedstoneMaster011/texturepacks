import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pyttsx3
import time
from pedalboard import Pedalboard, Delay, Reverb, Gain, PitchShift, HighpassFilter
from pedalboard.io import AudioFile
from pydub import AudioSegment

# --- RCB ENGINE FORCED LINKING ---
ffmpeg_folder = os.path.join(os.environ["LOCALAPPDATA"], "Microsoft", "WinGet", "Links")
os.environ["PATH"] += os.pathsep + ffmpeg_folder
AudioSegment.converter = os.path.join(ffmpeg_folder, "ffmpeg.exe")


# ---------------------------------

class RCB_Final_GUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Robot Text to Speech")
        self.root.geometry("450x350")

        main_frame = ttk.Frame(root, padding="25")
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(main_frame, text="Robot Text To Speech", font=("Courier", 14, "bold")).pack(pady=(0, 20))

        ttk.Label(main_frame, text="Text:").pack(anchor="w")
        self.text_input = tk.Text(main_frame, height=6, width=45)
        self.text_input.pack(pady=5)

        # Export Button (Now handles folder + name in explorer)
        self.export_btn = ttk.Button(main_frame, text="EXPORT", command=self.process_audio)
        self.export_btn.pack(pady=30, fill=tk.X)

    def process_audio(self):
        text = self.text_input.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning("Robot Text to Speech Warning", "No text detected.")
            return

        # OPEN FILE EXPLORER (Sets Name and Path at once)
        final_path = filedialog.asksaveasfilename(
            defaultextension=".ogg",
            filetypes=[("OGG files", "*.ogg")],
            initialfile="Text_To_Speech.ogg",
            title="Save Speech"
        )

        if not final_path:
            return

        temp_raw = "temp_raw.wav"
        temp_robot = "temp_robot.wav"
        beep_file = "beep_startup_part1.ogg"

        try:
            # 1. GENERATE RAW (Male Voice Lock)
            engine = pyttsx3.init()
            engine.setProperty('voice', None)
            voices = engine.getProperty('voices')

            for v in voices:
                if "david" in v.name.lower() or "male" in v.name.lower():
                    engine.setProperty('voice', v.id)
                    break

            # Rate clamped to 100 to avoid System Error
            engine.setProperty('rate', 100)
            engine.save_to_file(text, temp_raw)
            engine.runAndWait()
            time.sleep(0.1)

            # 2. APPLY RCB EFFECTS (1.9x Gain + Your Pedalboard Logic)
            with AudioFile(temp_raw) as f:
                board = Pedalboard([
                    # Lower pitch (2.0) keeps it grounded and "industrial" like the alarms
                    PitchShift(semitones=2.0),

                    # Aggressive Highpass cuts out the "fleshy" human frequencies
                    HighpassFilter(cutoff_frequency_hz=1100),

                    # DOUBLE COMB FILTER: This is what creates that "Narakeet" ring
                    # Layering these two specific micro-delays vibrates the voice against itself
                    Delay(delay_seconds=0.0015, feedback=0.7, mix=0.5),
                    Delay(delay_seconds=0.003, feedback=0.5, mix=0.4),

                    # YOUR 2.5x POWER BOOST
                    Gain(gain_db=25.0),

                    # COLD METALLIC SPACE: Higher damping (0.8) makes the echo sound like steel, not a room
                    Reverb(width=0.6, damping=0.8, room_size=0.15),

                    # Standard signal delay from your original logic
                    Delay(delay_seconds=0.015, feedback=0.35)
                ])

                effected = board(f.read(f.frames), f.samplerate)
                with AudioFile(temp_robot, 'w', f.samplerate, f.num_channels) as o:
                    o.write(effected)

            # 3. GLUE STARTUP BEEP
            voice_seg = AudioSegment.from_wav(temp_robot)
            if os.path.exists(beep_file):
                final_output = AudioSegment.from_file(beep_file) + voice_seg
            else:
                final_output = voice_seg

            final_output.export(final_path, format="ogg")
            messagebox.showinfo("Speech SUCCESS", f"Speech Saved Successfully.")

        except Exception as e:
            messagebox.showerror("Speech FAILURE", f"System Error: {e}")
        finally:
            for f in [temp_raw, temp_robot]:
                if os.path.exists(f):
                    try:
                        os.remove(f)
                    except:
                        pass


if __name__ == "__main__":
    root = tk.Tk()
    app = RCB_Final_GUI(root)
    root.mainloop()